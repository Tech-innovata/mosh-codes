from django.contrib import admin
from .models import Update,Student
# Register your models here.
admin.site.register(Update)
admin.site.register(Student)