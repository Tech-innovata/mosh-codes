from django.apps import AppConfig


class XmasappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'xmasapp'
