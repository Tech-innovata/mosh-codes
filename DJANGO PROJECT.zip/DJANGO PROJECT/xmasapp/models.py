from django.db import models

# Create your models here.
class Update(models.Model):
    Title = models.CharField(max_length=20)
    Paragraph=models.TextField(max_length=500)

class Student(models.Model):
    Name=models.CharField(max_length=30)
    Students_no=models.TextField(default=1900727591)
    Reg_no=models.CharField(max_length=30)
    Paragraphs=models.TextField(max_length=500,null=True,blank=True)
