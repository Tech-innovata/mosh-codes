from django.apps import AppConfig


class AcademicConfig(AppConfig):
    name = 'academic'
