from django.contrib import admin

from .models import SubjectRegistration

# Register your models here.
admin.site.register(SubjectRegistration)
