from django.apps import AppConfig


class EmployeeConfig(AppConfig):
    name = 'employee'
