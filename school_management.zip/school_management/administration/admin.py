from django.contrib import admin
from .models import Designation

admin.site.register(Designation)
